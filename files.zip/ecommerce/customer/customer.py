

def calculate_shipping():
    pass


def calc_tax():
    pass
